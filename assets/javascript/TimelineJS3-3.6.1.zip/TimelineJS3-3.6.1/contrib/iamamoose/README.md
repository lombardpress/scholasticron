We tested out using TimelineJS using a google spreadsheet but wanted to then move everything internal. Rather than rewrite everything I made this Python program that can take the spreadsheet and convert it to a json file which you can then host internally etc. As there is no contrib/ directory I didn't submit a MR, but feel free to create some place for this and request a MR from me instead. Submittted under MPL as per LICENSE.

See: https://github.com/NUKnightLab/TimelineJS3/issues/398
